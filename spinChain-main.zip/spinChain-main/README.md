# spinChain
Code for implementing spin chain simulations
